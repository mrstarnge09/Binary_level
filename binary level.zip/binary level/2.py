import re
import binascii

# Step 1: Take original password as input (visible)
original_password = input("Enter the original password: ")
print("Password received. Obfuscating at binary level...\n")


# Step 2: Compute structural counts from original (for filtering)
def count_categories(pwd):
    uppers = len(re.findall(r'[A-Z]', pwd))
    lowers = len(re.findall(r'[a-z]', pwd))
    digits = len(re.findall(r'\d', pwd))
    specials = len(re.findall(r'[^a-zA-Z0-9]', pwd))
    return (uppers, lowers, digits, specials)


target_counts = count_categories(original_password)
print(f"Target structure: {target_counts} (U, L, D, S)")

# Step 3: Encode to bytes and obfuscate (XOR with a single-byte key)
key = 0x5A  # Hardcoded key (90 in decimal) - can be made configurable
original_bytes = original_password.encode('utf-8')
obfuscated_bytes = bytearray(b ^ key for b in original_bytes)

# Print obfuscated as hex for binary insight
print("Obfuscated binary (hex):", obfuscated_bytes.hex().upper())
print("Length:", len(obfuscated_bytes), "bytes")
print("-" * 60)

# Step 4: Enhanced brute-force at binary level to find ALL passwords matching structure
print("Brute-forcing to recover ALL passwords matching structure...")
candidates = []  # List to store (key, password) tuples

for test_key in range(256):
    revealed_bytes = bytearray(b ^ test_key for b in obfuscated_bytes)
    try:
        revealed_text = revealed_bytes.decode('utf-8')
        # Filters: Printable ASCII, correct length, EXACT category counts from original
        u, l, d, s = count_categories(revealed_text)
        if (all(32 <= ord(c) <= 126 for c in revealed_text) and
                len(revealed_text) == len(original_password) and
                (u, l, d, s) == target_counts):
            is_original = (revealed_text == original_password)
            candidates.append((test_key, revealed_text, is_original))
    except UnicodeDecodeError:
        continue

# Step 5: Explicitly check the hardcoded key (as a fallback/confirmation)
hardcoded_recovered_bytes = bytearray(b ^ key for b in obfuscated_bytes)
try:
    hardcoded_recovered_text = hardcoded_recovered_bytes.decode('utf-8')
    hardcoded_is_original = (hardcoded_recovered_text == original_password)
    # Only add if not already in candidates (though it should be)
    if (key, hardcoded_recovered_text, hardcoded_is_original) not in candidates:
        candidates.append((key, hardcoded_recovered_text, hardcoded_is_original))
except UnicodeDecodeError:
    pass  # Shouldn't happen with known key

# Step 6: Sort candidates by key ascending and print results
if candidates:
    print(f"\nFound {len(candidates)} candidate(s) via binary brute-force (structure match):")
    print("-" * 80)
    print(f"{'Key (Dec)':<8} {'Key (Hex)':<8} {'Password':<25} {'Is Original?'}")
    print("-" * 80)
    for test_key, pwd, is_orig in sorted(candidates):  # Sort by key
        orig_mark = "YES" if is_orig else "NO"
        print(f"{test_key:<8} {hex(test_key):<8} {repr(pwd):<25} {orig_mark}")
    print("-" * 80)

    # Highlight the original if found
    original_key = next((k for k, p, orig in candidates if orig), None)
    if original_key is not None:
        print(f"\nOriginal password recovered with key {original_key} (0x{original_key:02X}): {original_password}")
    else:
        print("\nWarning: Original password not among candidates (unlikely, but check filters).")
else:
    print("No matching passwords found.")

print("\nProcess complete.")