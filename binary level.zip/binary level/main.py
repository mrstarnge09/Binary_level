import re

# Step 1: Take original password as input (visible)
original_password = input("Enter the original password: ")
print("Password received. Obfuscating at binary level...\n")

# Step 2: Compute structural counts from original (for filtering)
def count_categories(pwd):
    uppers = len(re.findall(r'[A-Z]', pwd))
    lowers = len(re.findall(r'[a-z]', pwd))
    digits = len(re.findall(r'\d', pwd))
    specials = len(re.findall(r'[^a-zA-Z0-9]', pwd))
    return (uppers, lowers, digits, specials)

target_counts = count_categories(original_password)
print(f"Target structure: {target_counts} (U, L, D, S)")

# Step 3: Encode to bytes and obfuscate (XOR with a single-byte key)
key = 0x5A  # Example key (90 in decimal)
original_bytes = original_password.encode('utf-8')
obfuscated_bytes = bytearray(b ^ key for b in original_bytes)

# Print obfuscated as hex for binary insight
print("Obfuscated binary (hex):", obfuscated_bytes.hex().upper())
print("Length:", len(obfuscated_bytes), "bytes")
print("-" * 40)

# Step 4: Brute-force at binary level to find password matching structure
print("Brute-forcing to recover password matching structure...")
found_key = None
found_password = None

for test_key in range(256):
    revealed_bytes = bytearray(b ^ test_key for b in obfuscated_bytes)
    try:
        revealed_text = revealed_bytes.decode('utf-8')
        # Filters: Printable ASCII, correct length, EXACT category counts from original
        u, l, d, s = count_categories(revealed_text)
        if (all(32 <= ord(c) <= 126 for c in revealed_text) and
            len(revealed_text) == len(original_password) and
            (u, l, d, s) == target_counts):
            found_key = test_key
            found_password = revealed_text
            break
    except UnicodeDecodeError:
        continue

# Step 5: Print the found password at last
if found_password:
    print("Recovered via binary brute-force (structure match):")
    print(f"Found key: {found_key} (0x{found_key:02X})")
    print(f"Found password: {found_password}")
else:
    print("No matching password found.")