import re
import math
import binascii

# Step 1: Take original password as input (visible) and optional key
original_password = input("Enter the original password: ")
key_input = input("Enter XOR key (hex, e.g., 0x5A) [default: 0x5A]: ").strip()
if key_input.lower().startswith('0x'):
    key = int(key_input, 16)
else:
    key = int(key_input) if key_input.isdigit() else 0x5A
print("Password received. Obfuscating at binary level...\n")


# Step 2: Compute structural counts and additional metrics from original (for filtering)
def count_categories(pwd):
    uppers = len(re.findall(r'[A-Z]', pwd))
    lowers = len(re.findall(r'[a-z]', pwd))
    digits = len(re.findall(r'\d', pwd))
    specials = len(re.findall(r'[^a-zA-Z0-9]', pwd))
    return (uppers, lowers, digits, specials)


def calculate_entropy(pwd):
    """Compute Shannon entropy for the password."""
    if not pwd:
        return 0.0
    freq = {}
    for char in pwd:
        freq[char] = freq.get(char, 0) + 1
    entropy = -sum((count / len(pwd)) * math.log2(count / len(pwd)) for count in freq.values())
    return entropy


def no_excessive_repeats(pwd, max_repeat=2):
    """Check if no more than max_repeat identical chars in a row."""
    if not pwd:
        return True
    prev = pwd[0]
    count = 1
    for char in pwd[1:]:
        if char == prev:
            count += 1
            if count > max_repeat:
                return False
        else:
            count = 1
            prev = char
    return True


# Common weak words to avoid (simple blacklist)
WEAK_WORDS = {'password', '123456', 'qwerty', 'admin', 'letmein'}


def is_weak(pwd):
    """Check if password contains common weak substrings."""
    lower_pwd = pwd.lower()
    return any(word in lower_pwd for word in WEAK_WORDS)


target_counts = count_categories(original_password)
original_entropy = calculate_entropy(original_password)
print(f"Target structure: {target_counts} (U, L, D, S)")
print(f"Original entropy: {original_entropy:.2f} bits/char")
print(f"Using key: 0x{key:02X} ({key} decimal)")

# Step 3: Encode to bytes and obfuscate (XOR with the key)
original_bytes = original_password.encode('utf-8')
obfuscated_bytes = bytearray(b ^ key for b in original_bytes)

# Print obfuscated as hex for binary insight
print("Obfuscated binary (hex):", obfuscated_bytes.hex().upper())
print("Length:", len(obfuscated_bytes), "bytes")
print("-" * 80)

# Step 4: Enhanced brute-force at binary level to find ALL passwords matching criteria
print("Brute-forcing to recover ALL passwords matching enhanced criteria...")
candidates = []  # List to store (key, password, entropy, is_original, score) tuples
min_entropy = max(2.5, original_entropy * 0.8)  # Require at least 80% of original entropy

for test_key in range(256):
    revealed_bytes = bytearray(b ^ test_key for b in obfuscated_bytes)
    try:
        revealed_text = revealed_bytes.decode('utf-8')
        # Core Filters: Printable ASCII, correct length, EXACT category counts
        u, l, d, s = count_categories(revealed_text)
        if (all(32 <= ord(c) <= 126 for c in revealed_text) and
                len(revealed_text) == len(original_password) and
                (u, l, d, s) == target_counts):
            # Enhanced Filters: Entropy threshold, no excessive repeats, not weak
            ent = calculate_entropy(revealed_text)
            if (ent >= min_entropy and
                    no_excessive_repeats(revealed_text) and
                    not is_weak(revealed_text)):
                is_original = (revealed_text == original_password)
                # Simple score: 100 for exact, else based on entropy
                score = 100 if is_original else int(ent * 10)
                candidates.append((test_key, revealed_text, ent, is_original, score))
    except UnicodeDecodeError:
        continue

# Step 5: Explicitly check the provided key (as a fallback/confirmation)
hardcoded_recovered_bytes = bytearray(b ^ key for b in obfuscated_bytes)
try:
    hardcoded_recovered_text = hardcoded_recovered_bytes.decode('utf-8')
    hardcoded_ent = calculate_entropy(hardcoded_recovered_text)
    hardcoded_is_original = (hardcoded_recovered_text == original_password)
    # Only add if not already in candidates and passes filters
    if (all(32 <= ord(c) <= 126 for c in hardcoded_recovered_text) and
            len(hardcoded_recovered_text) == len(original_password) and
            count_categories(hardcoded_recovered_text) == target_counts and
            hardcoded_ent >= min_entropy and
            no_excessive_repeats(hardcoded_recovered_text) and
            not is_weak(hardcoded_recovered_text)):
        score = 100 if hardcoded_is_original else int(hardcoded_ent * 10)
        candidate_tuple = (key, hardcoded_recovered_text, hardcoded_ent, hardcoded_is_original, score)
        if candidate_tuple not in candidates:
            candidates.append(candidate_tuple)
except UnicodeDecodeError:
    pass

# Step 6: Sort candidates by score descending, then by key ascending
if candidates:
    sorted_candidates = sorted(candidates, key=lambda x: (-x[4], x[0]))  # High score first, then low key
    print(f"\nFound {len(sorted_candidates)} candidate(s) via binary brute-force (enhanced match):")
    print("-" * 100)
    print(f"{'Score':<6} {'Key (Dec)':<8} {'Key (Hex)':<8} {'Entropy':<8} {'Password':<30} {'Is Original?'}")
    print("-" * 100)
    for test_key, pwd, ent, is_orig, score in sorted_candidates:
        orig_mark = "YES" if is_orig else "NO"
        print(f"{score:<6} {test_key:<8} {hex(test_key):<8} {ent:<8.2f} {repr(pwd):<30} {orig_mark}")
    print("-" * 100)

    # Highlight the original if found
    original_entry = next(((k, p, e) for k, p, e, orig, s in sorted_candidates if orig), None)
    if original_entry:
        orig_key, orig_pwd, orig_ent = original_entry
        print(f"\n🎉 Original password recovered with key {orig_key} (0x{orig_key:02X}): {repr(original_password)}")
        print(f"   (Entropy: {orig_ent:.2f} bits/char)")
    else:
        print("\n⚠️  Warning: Original password not among candidates (check filters or key).")
else:
    print("No matching passwords found with enhanced filters.")

print("\nProcess complete.")