import re

# Step 1: Read the HTML source from file (save the provided HTML as 'login.html')
with open('login.html', 'r', encoding='utf-8') as f:
    html = f.read()

# Step 2: Extract username and password from JS in source
username_match = re.search(r'const CORRECT_USERNAME\s*=\s*"([^"]+)";', html)
password_match = re.search(r'const CORRECT_PASSWORD\s*=\s*"([^"]+)";', html)

if not (username_match and password_match):
    print("Could not extract credentials from HTML source.")
    exit(1)

extracted_username = username_match.group(1)
original_password = password_match.group(1)
print(f"Extracted Username from source: {extracted_username}")

# Step 3: Brute-force username at binary level (simulate obfuscation and recovery)
def count_categories(pwd):
    uppers = len(re.findall(r'[A-Z]', pwd))
    lowers = len(re.findall(r'[a-z]', pwd))
    digits = len(re.findall(r'\d', pwd))
    specials = len(re.findall(r'[^a-zA-Z0-9]', pwd))
    return (uppers, lowers, digits, specials)

# For username (all digits, length 5)
username_target_counts = count_categories(extracted_username)
key = 0x5A
username_bytes = extracted_username.encode('utf-8')
obfuscated_username_bytes = bytearray(b ^ key for b in username_bytes)
print(f"\nSimulating brute-force on username (target structure: {username_target_counts} (U, L, D, S))")
print(f"Obfuscated username binary (hex): {obfuscated_username_bytes.hex().upper()}")
print("Length:", len(obfuscated_username_bytes), "bytes")
print("-" * 40)
print("Brute-forcing possible usernames matching structure...")

username_candidates = []
for test_key in range(256):
    revealed_bytes = bytearray(b ^ test_key for b in obfuscated_username_bytes)
    try:
        revealed_text = revealed_bytes.decode('utf-8')
        u, l, d, s = count_categories(revealed_text)
        if (all(32 <= ord(c) <= 126 for c in revealed_text) and
            len(revealed_text) == len(extracted_username) and
            (u, l, d, s) == username_target_counts):
            username_candidates.append((test_key, revealed_text))
    except UnicodeDecodeError:
        continue

print(f"Found {len(username_candidates)} possible usernames:")
for test_key, uname in username_candidates:
    print(f"  Key {test_key} (0x{test_key:02X}): {uname}")

# Assume targeted username is input (brute-force selects matching one)
targeted_username = input("\nEnter targeted username to check: ").strip()
if any(uname == targeted_username for _, uname in username_candidates):
    print(f"Targeted username '{targeted_username}' is a candidate. Proceeding to password recovery...")
else:
    print(f"Targeted username '{targeted_username}' not found in candidates.")
    exit(1)

# Step 4: Brute-force password
password_target_counts = count_categories(original_password)
print(f"\nTarget password structure: {password_target_counts} (U, L, D, S)")
original_bytes = original_password.encode('utf-8')
obfuscated_bytes = bytearray(b ^ key for b in original_bytes)
print("Obfuscated password binary (hex):", obfuscated_bytes.hex().upper())
print("Length:", len(obfuscated_bytes), "bytes")
print("-" * 40)
print("Brute-forcing to recover password matching structure...")

found_key = None
found_password = None
for test_key in range(256):
    revealed_bytes = bytearray(b ^ test_key for b in obfuscated_bytes)
    try:
        revealed_text = revealed_bytes.decode('utf-8')
        u, l, d, s = count_categories(revealed_text)
        if (all(32 <= ord(c) <= 126 for c in revealed_text) and
            len(revealed_text) == len(original_password) and
            (u, l, d, s) == password_target_counts):
            found_key = test_key
            found_password = revealed_text
            break
    except UnicodeDecodeError:
        continue

if found_password:
    print("Recovered via binary brute-force (structure match):")
    print(f"Found key: {found_key} (0x{found_key:02X})")
    print(f"Found password: {found_password}")
    print(f"Full credentials for targeted username '{targeted_username}': {found_password}")
else:
    print("No matching password found.")